# IoT Worksheet 03
## Shifaz Hassan - S1700461

Emoji Transmitter

- One device is a sender
- Other is a Reciever
- When the sender transmits BLE (Bluetooth Low Energy) signals , the receieving device decodes the signal to display relevant icon.
- Icons are mapped to numbers. Both sender and receiver have this mapping, so the actual images are not transmitted, but the identifiers that map the images are transmitted and decoded.