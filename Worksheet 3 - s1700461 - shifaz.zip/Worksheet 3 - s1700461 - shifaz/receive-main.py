# Imports go at the top
from microbit import *
import radio
import music

# Initialize radio and device
radio.on()
radio.config(group=10)

# Define event handler
def on_data_received():
    r_data = radio.receive()
    if r_data == "1":
        display.show(Image.HEART)
        music.play(music.HEART)
    elif r_data == "2":
        display.show(Image.DUCK)
        music.play(music.DUCK)
    elif r_data == "3":
        display.show(Image.SMILE)
        music.play(music.HAPPY)
    sleep(500)
    display.clear()

# Attach event handler
radio.on_received(on_data_received)

# Main loop
while True:
    sleep(1000)
