# Imports go at the top
from microbit import *
import radio
import music

# Set radio group
radio.config(group=10)
radio.on()

# Define button A and button B
button_a = button_b = False

# Define send function
def send():
    global button_a, button_b
    if button_a:
        radio.send("1")
        display.show(Image.HEART)
        music.play(music.HEART)
    elif button_b:
        radio.send("2")
        display.show(Image.DUCK)
        music.play(music.DUCK)
    else:
        radio.send("3")
        display.show(Image.SMILE)
        music.play(music.HAPPY)

    sleep(500)
    display.clear()

# Main loop
while True:
    button_a = button_a or button_a.was_pressed()
    button_b = button_b or button_b.was_pressed()

    if button_a or button_b:
        send()

    # Reset button states
    button_a = button_b = False
